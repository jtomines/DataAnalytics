/* slider_mv.js
UofT SCS Data Analytics Boot Camp
Project 3
Author:  Jose Tomines
Notes:  Slider for Measles/Vaccination in USA View.  Copied from 165_Final_Project in Github
*/

var step = 0;
var current_year = 1995;
var filename = ("data" + current_year + ".csv").toString();

display(current_year);

d3.select("#slider").on('change', function(d) {       
       var incrementation = parseInt(this.value);
       current_year = (1995 + incrementation);
       d3.select("#year").text(""+current_year);
       svg.selectAll("path").remove();
       svg.selectAll(".dot").remove();
       return display(current_year);
});